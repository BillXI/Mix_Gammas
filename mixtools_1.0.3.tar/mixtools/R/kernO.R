kern.O <- function (x, xi, h)
{
    (pi/4)*cos(.5*pi*(xi-x)/h)/h
}
